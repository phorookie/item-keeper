import { useState } from 'react'
import { View, Text, Input, Picker } from '@tarojs/components'
import Taro, { useRouter } from '@tarojs/taro'
import './index.scss'

const categories = [
  { label: '护肤品', value: 'skincare' },
  { label: '保健品', value: 'health' },
  { label: '食品', value: 'food' },
  { label: '日用品', value: 'daily' },
  { label: '衣物鞋包', value: 'clothing' },
  { label: '数码家电', value: 'digital' },
  { label: '其他', value: 'other' },
]

const presetTags = ['美白', '补水', '清洁', '保湿', '抗衰', '维生素', '益生菌', '提神']

export default function Add() {
  const router = useRouter()
  const isEdit = !!router.params.id

  const [name, setName] = useState('')
  const [categoryIndex, setCategoryIndex] = useState(0)
  const [brand, setBrand] = useState('')
  const [price, setPrice] = useState('')
  const [expireDate, setExpireDate] = useState('')
  const [openDate, setOpenDate] = useState('')
  const [tags, setTags] = useState<string[]>([])
  const [note, setNote] = useState('')
  const [tagInput, setTagInput] = useState('')

  const goBack = () => {
    Taro.navigateBack()
  }

  const addTag = (tag: string) => {
    if (tag && !tags.includes(tag)) {
      setTags([...tags, tag])
    }
    setTagInput('')
  }

  const removeTag = (tag: string) => {
    setTags(tags.filter(t => t !== tag))
  }

  const handleSave = () => {
    if (!name.trim()) {
      Taro.showToast({ title: '请输入物品名称', icon: 'none' })
      return
    }
    Taro.showToast({
      title: isEdit ? '已保存' : '添加成功',
      icon: 'success',
    })
    setTimeout(() => Taro.navigateBack(), 1000)
  }

  const chooseImage = () => {
    Taro.chooseImage({
      count: 3,
      success: res => {
        console.log('images:', res.tempFilePaths)
      },
    })
  }

  const onExpireDateChange = e => {
    setExpireDate(e.detail.value)
  }

  const onOpenDateChange = e => {
    setOpenDate(e.detail.value)
  }

  return (
    <View className='add'>
      {/* 顶部导航 */}
      <View className='add__nav'>
        <View className='add__nav-back' onClick={goBack}>
          <Text>‹</Text>
        </View>
        <Text className='add__nav-title'>{isEdit ? '编辑物品' : '添加物品'}</Text>
        <View className='add__nav-right' />
      </View>

      <ScrollView scrollY className='add__content'>
        {/* 照片上传 */}
        <View className='add__photo' onClick={chooseImage}>
          <Text className='add__photo-icon'>+</Text>
          <Text className='add__photo-text'>添加照片</Text>
          <Text className='add__photo-hint'>最多 3 张</Text>
        </View>

        {/* 物品信息 */}
        <View className='add__group'>
          <Text className='add__group-title'>物品信息</Text>

          <View className='add__field'>
            <Text className='add__field-label'>名称</Text>
            <Input
              className='add__field-input'
              placeholder='请输入物品名称'
              placeholderClass='add__field-placeholder'
              value={name}
              onInput={e => setName(e.detail.value)}
            />
          </View>

          <Picker
            mode='selector'
            range={categories.map(c => c.label)}
            value={categoryIndex}
            onChange={e => setCategoryIndex(Number(e.detail.value))}
          >
            <View className='add__field'>
              <Text className='add__field-label'>分类</Text>
              <View className='add__field-value'>
                <Text>{categories[categoryIndex].label}</Text>
                <Text className='add__field-arrow'>›</Text>
              </View>
            </View>
          </Picker>

          <View className='add__field'>
            <Text className='add__field-label'>品牌</Text>
            <Input
              className='add__field-input'
              placeholder='选填'
              placeholderClass='add__field-placeholder'
              value={brand}
              onInput={e => setBrand(e.detail.value)}
            />
          </View>
        </View>

        {/* 效期信息 */}
        <View className='add__group'>
          <Text className='add__group-title'>效期</Text>

          <Picker mode='date' value={expireDate} onChange={onExpireDateChange}>
            <View className='add__field'>
              <Text className='add__field-label'>保质期</Text>
              <View className='add__field-value'>
                <Text className={expireDate ? '' : 'add__field-placeholder'}>
                  {expireDate || '请选择日期'}
                </Text>
                <Text className='add__field-arrow'>›</Text>
              </View>
            </View>
          </Picker>

          <Picker mode='date' value={openDate} onChange={onOpenDateChange}>
            <View className='add__field'>
              <Text className='add__field-label'>开封日期</Text>
              <View className='add__field-value'>
                <Text className={openDate ? '' : 'add__field-placeholder'}>
                  {openDate || '未设置'}
                </Text>
                <Text className='add__field-arrow'>›</Text>
              </View>
            </View>
          </Picker>

          <View className='add__field'>
            <Text className='add__field-label'>价格</Text>
            <Input
              className='add__field-input'
              type='digit'
              placeholder='选填'
              placeholderClass='add__field-placeholder'
              value={price}
              onInput={e => setPrice(e.detail.value)}
            />
          </View>
        </View>

        {/* 功效标签 */}
        <View className='add__group'>
          <Text className='add__group-title'>功效标签</Text>
          <View className='add__tags'>
            {tags.map(tag => (
              <View key={tag} className='add__tag' onClick={() => removeTag(tag)}>
                <Text>{tag}</Text>
                <Text className='add__tag-close'> ×</Text>
              </View>
            ))}
            <View className='add__tag add__tag--add' onClick={() => addTag(tagInput)}>
              <Text>+ 添加</Text>
            </View>
          </View>
          <View className='add__tag-suggest'>
            <Text className='add__tag-suggest-label'>推荐：</Text>
            {presetTags
              .filter(t => !tags.includes(t))
              .slice(0, 5)
              .map(tag => (
                <Text
                  key={tag}
                  className='add__tag-suggest-item'
                  onClick={() => addTag(tag)}
                >
                  {tag}
                </Text>
              ))}
          </View>
        </View>

        {/* 备注 */}
        <View className='add__group'>
          <Text className='add__group-title'>备注</Text>
          <View className='add__note-area'>
            <Input
              className='add__note-input'
              placeholder='记录使用感受、购买渠道等...'
              placeholderClass='add__field-placeholder'
              value={note}
              onInput={e => setNote(e.detail.value)}
            />
          </View>
        </View>
      </ScrollView>

      {/* 保存按钮 */}
      <View className='add__save-btn' onClick={handleSave}>
        <Text>保存</Text>
      </View>
    </View>
  )
}
