import { useState, useMemo } from 'react'
import { View, Text, Input, ScrollView } from '@tarojs/components'
import Taro from '@tarojs/taro'
import './index.scss'

interface Item {
  id: string
  name: string
  category: string
  categoryLabel: string
  tags: string[]
  expireDate: string
  expireDays: number
  isExpiringSoon: boolean
  image: string
}

const mockItems: Item[] = [
  {
    id: '1',
    name: '氨基酸洗面奶',
    category: 'skincare',
    categoryLabel: '护肤品',
    tags: ['清洁', '温和'],
    expireDate: '2027-06-15',
    expireDays: 260,
    isExpiringSoon: false,
    image: '',
  },
  {
    id: '2',
    name: '深海鱼油',
    category: 'health',
    categoryLabel: '保健品',
    tags: ['Omega-3', '心脑血管'],
    expireDate: '2026-11-20',
    expireDays: 52,
    isExpiringSoon: true,
    image: '',
  },
  {
    id: '3',
    name: '烟酰胺原液',
    category: 'skincare',
    categoryLabel: '护肤品',
    tags: ['美白', '淡斑', '提亮'],
    expireDate: '2027-06-30',
    expireDays: 275,
    isExpiringSoon: false,
    image: '',
  },
  {
    id: '4',
    name: '维生素C片',
    category: 'health',
    categoryLabel: '保健品',
    tags: ['维C', '增强免疫'],
    expireDate: '2026-10-15',
    expireDays: 16,
    isExpiringSoon: true,
    image: '',
  },
  {
    id: '5',
    name: '纯棉洗脸巾',
    category: 'daily',
    categoryLabel: '日用品',
    tags: ['清洁', '棉柔'],
    expireDate: '',
    expireDays: -1,
    isExpiringSoon: false,
    image: '',
  },
  {
    id: '6',
    name: '益生菌粉',
    category: 'health',
    categoryLabel: '保健品',
    tags: ['肠道', '益生菌'],
    expireDate: '2027-02-10',
    expireDays: 134,
    isExpiringSoon: false,
    image: '',
  },
]

export default function Index() {
  const [searchText, setSearchText] = useState('')
  const [isSearching, setIsSearching] = useState(false)

  const expiringItems = mockItems.filter(item => item.isExpiringSoon)

  const filteredItems = useMemo(() => {
    if (!searchText.trim()) return mockItems
    const keyword = searchText.toLowerCase()
    return mockItems.filter(
      item =>
        item.name.toLowerCase().includes(keyword) ||
        item.tags.some(tag => tag.toLowerCase().includes(keyword)) ||
        item.categoryLabel.toLowerCase().includes(keyword)
    )
  }, [searchText])

  const goToDetail = (id: string) => {
    Taro.navigateTo({ url: `/pages/detail/index?id=${id}` })
  }

  const goToAdd = () => {
    Taro.navigateTo({ url: '/pages/add/index' })
  }

  return (
    <View className='home'>
      {/* 顶部问候 */}
      <View className='home__greeting'>
        <Text className='home__hello'>晚上好</Text>
        <Text className='home__title'>你的物品</Text>
      </View>

      {/* 搜索栏 */}
      <View className='home__search'>
        <Text className='home__search-icon'>⌕</Text>
        <Input
          className='home__search-input'
          placeholder='搜索名称、功效、标签...'
          placeholderClass='home__search-placeholder'
          value={searchText}
          onInput={e => setSearchText(e.detail.value)}
          onFocus={() => setIsSearching(true)}
        />
        {isSearching && searchText && (
          <Text
            className='home__search-cancel'
            onClick={() => {
              setSearchText('')
              setIsSearching(false)
            }}
          >
            取消
          </Text>
        )}
      </View>

      <ScrollView scrollY className='home__content'>
        {/* 搜索结果 */}
        {searchText.trim() ? (
          <View className='home__search-results'>
            {filteredItems.length > 0 && (
              <View className='home__search-tip'>
                <Text className='home__search-tip-icon'>💡</Text>
                <Text className='home__search-tip-text'>
                  你已有 {filteredItems.length} 件「{searchText}」相关物品
                </Text>
              </View>
            )}
            <View className='home__section-title'>
              <Text className='home__section-title-text'>搜索结果</Text>
              <Text className='home__section-title-count'>{filteredItems.length} 件</Text>
            </View>
            {filteredItems.length === 0 ? (
              <View className='home__empty'>
                <Text className='home__empty-text'>没有找到相关物品</Text>
              </View>
            ) : (
              filteredItems.map(item => (
                <View
                  key={item.id}
                  className='item-row'
                  onClick={() => goToDetail(item.id)}
                >
                  <View className='item-row__thumb' />
                  <View className='item-row__info'>
                    <Text className='item-row__name'>{item.name}</Text>
                    <Text className='item-row__meta'>
                      {item.categoryLabel}
                      {item.expireDays >= 0
                        ? ` · 还有 ${item.expireDays} 天`
                        : ' · 无保质期'}
                    </Text>
                  </View>
                  <Text className='item-row__arrow'>›</Text>
                </View>
              ))
            )}
          </View>
        ) : (
          <>
            {/* 临期提醒 */}
            {expiringItems.length > 0 && (
              <View className='home__section'>
                <View className='home__section-title'>
                  <Text className='home__section-title-text'>即将过期</Text>
                  <Text className='home__section-title-count'>{expiringItems.length} 件</Text>
                </View>
                {expiringItems.map(item => (
                  <View
                    key={item.id}
                    className='expiring-item'
                    onClick={() => goToDetail(item.id)}
                  >
                    <View className='expiring-item__thumb' />
                    <View className='expiring-item__info'>
                      <Text className='expiring-item__name'>{item.name}</Text>
                      <Text className='expiring-item__time'>
                        还有 {item.expireDays} 天过期
                      </Text>
                    </View>
                  </View>
                ))}
              </View>
            )}

            {/* 全部物品 */}
            <View className='home__section'>
              <View className='home__section-title'>
                <Text className='home__section-title-text'>全部物品</Text>
                <Text className='home__section-title-count'>{mockItems.length} 件</Text>
              </View>
              {mockItems.map(item => (
                <View
                  key={item.id}
                  className='item-row'
                  onClick={() => goToDetail(item.id)}
                >
                  <View className='item-row__thumb' />
                  <View className='item-row__info'>
                    <Text className='item-row__name'>{item.name}</Text>
                    <Text className='item-row__meta'>
                      {item.categoryLabel}
                      {item.expireDays >= 0
                        ? ` · 还有 ${item.expireDays} 天`
                        : ' · 无保质期'}
                    </Text>
                  </View>
                  <Text className='item-row__arrow'>›</Text>
                </View>
              ))}
            </View>
          </>
        )}
      </ScrollView>

      {/* 浮动添加按钮 */}
      <View className='home__fab' onClick={goToAdd}>
        <Text className='home__fab-icon'>+</Text>
      </View>
    </View>
  )
}
