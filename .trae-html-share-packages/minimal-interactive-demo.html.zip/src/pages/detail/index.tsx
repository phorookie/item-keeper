import { useState, useEffect } from 'react'
import { View, Text, ScrollView } from '@tarojs/components'
import Taro, { useRouter } from '@tarojs/taro'
import './index.scss'

const mockDetail = {
  id: '3',
  name: '烟酰胺原液',
  category: 'skincare',
  categoryLabel: '护肤品 › 精华',
  brand: 'HFP',
  price: 189,
  purchaseDate: '2026-03-15',
  expireDate: '2027-06-30',
  expireDays: 275,
  openDate: '2026-08-01',
  openExpireDays: 30,
  tags: ['美白', '淡斑', '提亮'],
  note: '晚上使用，每次 3-4 滴，搭配面霜效果更好。注意避光，白天使用需要涂防晒。',
  image: '',
}

export default function Detail() {
  const router = useRouter()
  const [item, setItem] = useState(mockDetail)

  useEffect(() => {
    const id = router.params.id
    // 这里可以根据 id 请求详情数据，目前用 mock
    console.log('item id:', id)
  }, [router.params.id])

  const goBack = () => {
    Taro.navigateBack()
  }

  const goEdit = () => {
    Taro.navigateTo({ url: `/pages/add/index?id=${item.id}` })
  }

  const markUsed = () => {
    Taro.showModal({
      title: '确认用完了吗？',
      content: '标记后物品将移至历史记录',
      confirmText: '标记用完',
      confirmColor: '#1C1B1A',
      success: res => {
        if (res.confirm) {
          Taro.showToast({ title: '已标记', icon: 'success' })
          setTimeout(() => Taro.navigateBack(), 1000)
        }
      },
    })
  }

  return (
    <View className='detail'>
      {/* 顶部图片区 */}
      <View className='detail__hero'>
        <View className='detail__hero-bg' />
        <View className='detail__nav'>
          <View className='detail__nav-btn' onClick={goBack}>
            <Text>‹</Text>
          </View>
          <View className='detail__nav-btn' onClick={goEdit}>
            <Text>⋯</Text>
          </View>
        </View>
      </View>

      <ScrollView scrollY className='detail__content'>
        {/* 标题区 */}
        <View className='detail__header'>
          <Text className='detail__title'>{item.name}</Text>
          <Text className='detail__category'>{item.categoryLabel}</Text>

          <View className='detail__status'>
            <Text className='detail__status-icon'>⏱</Text>
            <Text className='detail__status-text'>
              保质期还有 {item.expireDays} 天 · 开封后剩余 {item.openExpireDays} 天
            </Text>
          </View>
        </View>

        {/* 标签 */}
        <View className='detail__section'>
          <Text className='detail__section-title'>功效标签</Text>
          <View className='detail__tags'>
            {item.tags.map(tag => (
              <Text key={tag} className='detail__tag'>
                {tag}
              </Text>
            ))}
          </View>
        </View>

        {/* 基本信息 */}
        <View className='detail__section'>
          <Text className='detail__section-title'>基本信息</Text>
          <View className='detail__info-list'>
            <View className='detail__info-row'>
              <Text className='detail__info-label'>品牌</Text>
              <Text className='detail__info-value'>{item.brand}</Text>
            </View>
            <View className='detail__info-row'>
              <Text className='detail__info-label'>价格</Text>
              <Text className='detail__info-value'>¥ {item.price}</Text>
            </View>
            <View className='detail__info-row'>
              <Text className='detail__info-label'>购买日期</Text>
              <Text className='detail__info-value'>{item.purchaseDate}</Text>
            </View>
            <View className='detail__info-row'>
              <Text className='detail__info-label'>保质期至</Text>
              <Text className='detail__info-value detail__info-value--warning'>
                {item.expireDate}
              </Text>
            </View>
            <View className='detail__info-row'>
              <Text className='detail__info-label'>开封日期</Text>
              <Text className='detail__info-value'>{item.openDate}</Text>
            </View>
          </View>
        </View>

        {/* 备注 */}
        <View className='detail__section'>
          <Text className='detail__section-title'>备注</Text>
          <Text className='detail__note'>{item.note}</Text>
        </View>

        {/* 底部操作区 */}
        <View className='detail__actions'>
          <View className='detail__btn detail__btn--ghost' onClick={markUsed}>
            <Text>标记用完</Text>
          </View>
          <View className='detail__btn detail__btn--primary' onClick={goEdit}>
            <Text>编辑</Text>
          </View>
        </View>
      </ScrollView>
    </View>
  )
}
