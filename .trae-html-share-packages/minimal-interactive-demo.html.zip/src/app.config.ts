export default defineAppConfig({
  pages: [
    'pages/index/index',
    'pages/detail/index',
    'pages/add/index',
  ],
  window: {
    backgroundTextStyle: 'light',
    navigationBarBackgroundColor: '#FAFAF8',
    navigationBarTitleText: '物品管家',
    navigationBarTextStyle: 'black',
    backgroundColor: '#FAFAF8',
  },
  tabBar: {
    color: '#9A9793',
    selectedColor: '#1C1B1A',
    backgroundColor: '#FFFFFF',
    borderStyle: 'white',
    list: [
      {
        pagePath: 'pages/index/index',
        text: '首页',
      },
    ],
  },
})
